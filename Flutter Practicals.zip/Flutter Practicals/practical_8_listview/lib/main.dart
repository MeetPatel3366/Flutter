import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('ListView Example'),
        ),
        body: ListView(
          children: <Widget>[
            ListTile(
              leading: Icon(Icons.star),
              title: Text('Item 1'),
            ),
            ListTile(
              leading: Icon(Icons.star),
              title: Text('Item 2'),
            ),
            ListTile(
              leading: Icon(Icons.star),
              title: Text('Item 3'),
            ),
            // Add more list items as needed
          ],
        ),
      ),
    );
  }
}
