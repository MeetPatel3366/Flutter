import 'package:flutter/material.dart';

void main() {
  runApp(
    // runApp: The entry point of the Flutter app that initializes and starts the app.
    MaterialApp(
      debugShowCheckedModeBanner: false, // Disables the debug banner that shows in debug mode
      home: Scaffold(
        // Scaffold: A basic visual structure that provides AppBar, body, and other layout elements
        appBar: AppBar(
          title: Text(
            'My App', // App title displayed in the AppBar
            style: TextStyle(
              color: Colors.white, // Title text color
              fontSize: 25, // Title text size
              fontWeight: FontWeight.bold, // Title text weight (bold)
            ),
          ),
          backgroundColor: Colors.red, // AppBar background color
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center, // Center the column widgets
            children: [
              Text(
                'Hello, Flutter!', // Displayed text in the body
                style: TextStyle(
                  color: Colors.green, // Text color
                  fontSize: 40, // Text size
                  fontStyle: FontStyle.italic, // Italic text style
                ),
              ),
              SizedBox(height: 20), // Adds vertical space
              Row(
                mainAxisAlignment: MainAxisAlignment.center, // Centers icons horizontally
                children: [
                  Icon(
                    Icons.star, // Icon: Star icon
                    size: 70.0, // Icon size
                    color: Colors.redAccent, // Icon color
                  ),
                  SizedBox(width: 20), // Adds space between icons
                  Icon(
                    Icons.account_balance_wallet_outlined, // Icon: Wallet icon
                    size: 70.0, // Icon size
                    color: Colors.pink, // Icon color
                  ),
                  SizedBox(width: 20), // Adds space between icons
                  Icon(
                    Icons.account_tree, // Icon: Tree icon
                    size: 70.0, // Icon size
                    color: Colors.purple, // Icon color
                  ),
                ],
              ),
              SizedBox(height: 20), // Adds space between icons and container
              Container(
                width: 200.0,
                height: 200.0,
                padding: EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0), // Padding horizontal & vertical
                decoration: BoxDecoration(
                  color: Colors.blue, // Container background color
                  border: Border.all(
                    color: Colors.black, // Border color
                    width: 2, // Border width
                  ),
                  borderRadius: BorderRadius.circular(15), // Border radius (rounded corners)
                ),
                child: Center( // This will center the text inside the container
                  child: Text(
                    'Meet', // Text inside the container
                    style: TextStyle(
                      color: Colors.white, // Text color
                      fontSize: 20, // Text font size
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        backgroundColor: Colors.grey[200], // Body background color
      ),
    ),
  );
}
