import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('GridView Example'),
        ),
        body: GridView.count(
          crossAxisCount: 2,
          children: List.generate(6, (index) {
            return Container(
              margin: EdgeInsets.all(8.0),
              color: Colors.blueGrey[100 * (index % 9)],
              child: Center(
                child: Text(
                  'Item $index',
                  style: TextStyle(fontSize: 20),
                ),
              ),
            );
          }),
        ),
      ),
    );
  }
}
