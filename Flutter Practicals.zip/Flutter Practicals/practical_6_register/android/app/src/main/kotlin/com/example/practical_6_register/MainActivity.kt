package com.example.practical_6_register

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
