package com.example.practical_5_login;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
